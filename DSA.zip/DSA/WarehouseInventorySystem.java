import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class WarehouseInventorySystem {
    private static final BufferedReader INPUT =
            new BufferedReader(new InputStreamReader(System.in));

    private final Inventory inventory = new Inventory();
    private final Corpus corpus = new Corpus();

    public static void main(String[] args) throws IOException {
        WarehouseInventorySystem app = new WarehouseInventorySystem();
        if (args.length > 0 && "--self-test".equals(args[0])) {
            app.runSelfTests();
            return;
        }
        app.run();
    }

    private void run() throws IOException {
        inventory.loadSampleData();
        corpus.load(Paths.get("corpus"));
        System.out.println("Warehouse Inventory System - DSA algorithm demonstrations");
        System.out.println("Loaded " + corpus.size + " warehouse corpus document(s).");
        boolean running = true;
        while (running) {
            printMenu();
            String choice = prompt("Choose an option: ");
            if (choice == null) {
                break;
            }
            switch (choice.trim()) {
                case "1":
                    inventory.printAll();
                    break;
                case "2":
                    addProduct();
                    break;
                case "3":
                    updateStock();
                    break;
                case "4":
                    removeProduct();
                    break;
                case "5":
                    searchProducts();
                    break;
                case "6":
                    compareDescriptions();
                    break;
                case "7":
                    allocateStock();
                    break;
                case "8":
                    runDynamicProgrammingDemos();
                    break;
                case "9":
                    approximatePickPlan();
                    break;
                case "10":
                    testPrime();
                    break;
                case "11":
                    runSamplingAndParallelSummary();
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("Enter a listed menu number.");
            }
        }
        System.out.println("Goodbye.");
    }

    private void printMenu() {
        System.out.println();
        System.out.println("1. List inventory");
        System.out.println("2. Add product");
        System.out.println("3. Update stock");
        System.out.println("4. Delete product");
        System.out.println("5. Text search (inventory or corpus; KMP, Z, double hash, multi-pattern, fuzzy)");
        System.out.println("6. Compare product descriptions (suffix array and LCP)");
        System.out.println("7. Allocate stock to outlets (Dinic max-flow)");
        System.out.println("8. Restock budget and pick-route DP demonstrations");
        System.out.println("9. Approximate pick-conflict plan (2-approximation)");
        System.out.println("10. Test a large prime (Miller-Rabin)");
        System.out.println("11. Low-stock sample and parallel summary");
        System.out.println("0. Exit");
    }

    private void addProduct() throws IOException {
        String sku = prompt("SKU: ");
        String name = prompt("Product name: ");
        String description = prompt("Description: ");
        int quantity = readNonNegativeInt("Quantity: ");
        int reorder = readNonNegativeInt("Restock threshold: ");
        int aisle = readNonNegativeInt("Aisle number: ");
        if (sku == null || name == null || description == null) {
            return;
        }
        if (sku.trim().isEmpty() || name.trim().isEmpty()) {
            System.out.println("SKU and name cannot be empty.");
            return;
        }
        if (inventory.findBySku(sku) >= 0) {
            System.out.println("That SKU already exists.");
            return;
        }
        inventory.add(new Product(sku.trim(), name.trim(), description.trim(),
                quantity, reorder, aisle));
        System.out.println("Product added.");
    }

    private void updateStock() throws IOException {
        String sku = prompt("SKU to update: ");
        if (sku == null) {
            return;
        }
        int index = inventory.findBySku(sku.trim());
        if (index < 0) {
            System.out.println("No product has that SKU.");
            return;
        }
        inventory.products[index].quantity = readNonNegativeInt("New quantity: ");
        System.out.println("Stock updated.");
    }

    private void removeProduct() throws IOException {
        String sku = prompt("SKU to delete: ");
        if (sku != null && inventory.removeBySku(sku.trim())) {
            System.out.println("Product deleted.");
        } else if (sku != null) {
            System.out.println("No product has that SKU.");
        }
    }

    private void searchProducts() throws IOException {
        String scope = prompt("Search [1 inventory, 2 corpus documents]: ");
        if (scope == null || (!"1".equals(scope.trim()) && !"2".equals(scope.trim()))) {
            System.out.println("Choose 1 for inventory or 2 for corpus documents.");
            return;
        }
        String query = prompt("Search text: ");
        if (query == null || query.isEmpty()) {
            System.out.println("Search text cannot be empty.");
            return;
        }
        String mode = prompt("Mode [1 KMP, 2 Z, 3 double hash, 4 multiple terms, 5 fuzzy]: ");
        if (mode == null) {
            return;
        }
        mode = mode.trim();
        if (!"1".equals(mode) && !"2".equals(mode) && !"3".equals(mode)
                && !"4".equals(mode) && !"5".equals(mode)) {
            System.out.println("Unknown search mode.");
            return;
        }
        String[] terms;
        if ("4".equals(mode)) {
            String second = prompt("Second term: ");
            if (second == null || second.isEmpty()) {
                System.out.println("Both terms must be non-empty.");
                return;
            }
            terms = new String[] {query, second};
        } else {
            terms = new String[] {query};
        }
        int maxDistance = 0;
        if ("5".equals(mode)) {
            maxDistance = readNonNegativeInt("Maximum edit distance: ");
        }
        int found = 0;
        if ("1".equals(scope.trim())) {
            for (int i = 0; i < inventory.size; i++) {
                Product product = inventory.products[i];
                String searchable = product.sku + " " + product.name + " "
                        + product.description;
                if (matchesSearch(searchable, query, mode, terms, maxDistance)) {
                    inventory.printProduct(product);
                    found++;
                }
            }
        } else {
            for (int i = 0; i < corpus.size; i++) {
                if (matchesSearch(corpus.contents[i], query, mode, terms, maxDistance)) {
                    System.out.println(corpus.names[i] + ": " + corpus.preview(i));
                    found++;
                }
            }
        }
        System.out.println(found + ("1".equals(scope.trim())
                ? " matching product(s)." : " matching corpus document(s)."));
    }

    private static boolean matchesSearch(String text, String query, String mode,
                                         String[] terms, int maxDistance) {
        String searchable = text.toLowerCase();
        String normalizedQuery = query.toLowerCase();
        switch (mode) {
            case "1":
                return StringAlgorithms.kmpIndexOf(searchable, normalizedQuery) >= 0;
            case "2":
                return StringAlgorithms.zIndexOf(searchable, normalizedQuery) >= 0;
            case "3":
                return StringAlgorithms.rabinKarpIndexOf(searchable, normalizedQuery) >= 0;
            case "4":
                return StringAlgorithms.ahoCorasickContainsAny(searchable, terms);
            case "5":
                return StringAlgorithms.fuzzyContains(
                        searchable, normalizedQuery, maxDistance);
            default:
                System.out.println("Unknown search mode.");
                return false;
        }
    }

    private void compareDescriptions() throws IOException {
        String firstSku = prompt("First SKU: ");
        String secondSku = prompt("Second SKU: ");
        if (firstSku == null || secondSku == null) {
            return;
        }
        int first = inventory.findBySku(firstSku.trim());
        int second = inventory.findBySku(secondSku.trim());
        if (first < 0 || second < 0) {
            System.out.println("Both SKUs must exist.");
            return;
        }
        String common = StringAlgorithms.longestCommonSubstring(
                inventory.products[first].description,
                inventory.products[second].description);
        System.out.println("Longest shared description substring: \""
                + common + "\" (" + common.length() + " characters)");
    }

    private void allocateStock() throws IOException {
        if (inventory.size == 0) {
            System.out.println("There is no stock to allocate.");
            return;
        }
        int outlets = readBoundedInt("Number of outlets (1-8): ", 1, 8);
        int[] demand = new int[outlets];
        for (int i = 0; i < outlets; i++) {
            demand[i] = readNonNegativeInt("Demand for outlet " + (i + 1) + ": ");
        }

        int source = 0;
        int firstProduct = 1;
        int firstOutlet = firstProduct + inventory.size;
        int sink = firstOutlet + outlets;
        Dinic flow = new Dinic(sink + 1, (inventory.size * outlets) + inventory.size + outlets);
        for (int i = 0; i < inventory.size; i++) {
            flow.addEdge(source, firstProduct + i, inventory.products[i].quantity);
            for (int j = 0; j < outlets; j++) {
                flow.addEdge(firstProduct + i, firstOutlet + j,
                        inventory.products[i].quantity);
            }
        }
        for (int i = 0; i < outlets; i++) {
            flow.addEdge(firstOutlet + i, sink, demand[i]);
        }
        int allocated = flow.maxFlow(source, sink);
        System.out.println("Maximum allocatable units: " + allocated);
        System.out.println("Outlet allocations:");
        for (int i = 0; i < outlets; i++) {
            System.out.println("  Outlet " + (i + 1) + ": "
                    + flow.flowOnEdge(firstOutlet + i, sink) + " / " + demand[i]);
        }
        System.out.println("Unmet demand: " + (sum(demand) - allocated));
    }

    private void runDynamicProgrammingDemos() throws IOException {
        int capacity = readNonNegativeInt("Restock budget in units: ");
        int count = 0;
        for (int i = 0; i < inventory.size; i++) {
            if (inventory.products[i].quantity < inventory.products[i].reorderLevel) {
                count++;
            }
        }
        int[] weights = new int[count];
        int[] values = new int[count];
        int item = 0;
        for (int i = 0; i < inventory.size; i++) {
            Product product = inventory.products[i];
            if (product.quantity < product.reorderLevel) {
                int shortage = product.reorderLevel - product.quantity;
                weights[item] = shortage;
                values[item] = 10 + (product.reorderLevel >= 20 ? 5 : 0);
                item++;
            }
        }
        int chosenValue = DynamicProgramming.bestRestockValue(weights, values, capacity);
        System.out.println("0/1 restock knapsack value within budget: " + chosenValue);

        if (inventory.size == 0) {
            System.out.println("No products are available for a pick route.");
            return;
        }
        if (inventory.size > 12) {
            System.out.println("Bitmask TSP route is limited to 12 products; current inventory has "
                    + inventory.size + ".");
            return;
        }
        int[] aisles = new int[inventory.size];
        for (int i = 0; i < inventory.size; i++) {
            aisles[i] = inventory.products[i].aisle;
        }
        int routeCost = DynamicProgramming.minimumAisleTour(aisles);
        System.out.println("Shortest aisle tour (start/end at first product): "
                + routeCost + " aisle units.");
        System.out.println("This exact bitmask-DP route takes O(2^n * n^2) time and O(2^n * n) space.");
    }

    private void approximatePickPlan() {
        int n = inventory.size;
        boolean[][] conflicts = new boolean[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                conflicts[i][j] = inventory.products[i].aisle == inventory.products[j].aisle;
                conflicts[j][i] = conflicts[i][j];
            }
        }
        boolean[] matched = new boolean[n];
        boolean[] cover = new boolean[n];
        int matchedPairs = 0;
        for (int i = 0; i < n; i++) {
            if (matched[i]) {
                continue;
            }
            for (int j = i + 1; j < n; j++) {
                if (conflicts[i][j] && !matched[j]) {
                    matched[i] = true;
                    matched[j] = true;
                    cover[i] = true;
                    cover[j] = true;
                    matchedPairs++;
                    break;
                }
            }
        }
        if (matchedPairs == 0) {
            System.out.println("No same-aisle task conflicts; every product can be picked in parallel.");
            return;
        }
        System.out.println("2-approximate vertex cover: serialize/coordinate these same-aisle tasks:");
        for (int i = 0; i < n; i++) {
            if (cover[i]) {
                System.out.println("  " + inventory.products[i].sku + " - "
                        + inventory.products[i].name + " (aisle " + inventory.products[i].aisle + ")");
            }
        }
        System.out.println("Selected " + (matchedPairs * 2) + " tasks from "
                + matchedPairs + " greedily chosen disjoint conflict pair(s).");
    }

    private void testPrime() throws IOException {
        long value = readLong("Product batch ID / number to test: ");
        boolean probablePrime = RandomizedAlgorithms.isProbablePrime(value, 16);
        System.out.println(value + (probablePrime
                ? " is probably prime (16 randomized Miller-Rabin rounds)."
                : " is composite."));
    }

    private void runSamplingAndParallelSummary() {
        int lowStockCount = 0;
        for (int i = 0; i < inventory.size; i++) {
            if (inventory.products[i].quantity < inventory.products[i].reorderLevel) {
                lowStockCount++;
            }
        }
        if (lowStockCount == 0) {
            System.out.println("No products are currently below their restock threshold.");
        } else {
            int[] lowStockIndices = new int[lowStockCount];
            int next = 0;
            for (int i = 0; i < inventory.size; i++) {
                if (inventory.products[i].quantity < inventory.products[i].reorderLevel) {
                    lowStockIndices[next++] = i;
                }
            }
            int sampleSize = Math.min(3, lowStockCount);
            int[] sample = RandomizedAlgorithms.reservoirSample(lowStockIndices, sampleSize);
            System.out.println("Uniform reservoir sample of low-stock products:");
            for (int index : sample) {
                Product product = inventory.products[index];
                System.out.println("  " + product.sku + " - " + product.name
                        + " (" + product.quantity + " in stock)");
            }
        }
        int[] quantities = new int[inventory.size];
        for (int i = 0; i < inventory.size; i++) {
            quantities[i] = inventory.products[i].quantity;
        }
        long total = ParallelAlgorithms.parallelSum(quantities);
        long[] prefix = ParallelAlgorithms.parallelPrefixSum(quantities);
        System.out.println("Parallel stock total: " + total + " units.");
        System.out.println("Parallel prefix totals by product: " + format(prefix));
        System.out.println("Work is O(n); the chunked scan has O(n/p + p) span "
                + "for p worker chunks.");
    }

    private void runSelfTests() throws IOException {
        check(StringAlgorithms.kmpIndexOf("ababcabc", "abc") == 2, "KMP");
        check(StringAlgorithms.zIndexOf("ababcabc", "abc") == 2, "Z search");
        check(StringAlgorithms.rabinKarpIndexOf("ababcabc", "abc") == 2, "double hash");
        check(StringAlgorithms.ahoCorasickContainsAny("warehouse stock", new String[] {
                "forklift", "stock"
        }), "Aho-Corasick");
        check(StringAlgorithms.editDistance("kitten", "sitting") == 3, "edit distance");
        check(StringAlgorithms.fuzzyContains("shipping box", "shiping", 1),
                "fuzzy substring search");
        check(!StringAlgorithms.fuzzyContains("shipping box", "forklift", 1),
                "fuzzy search distance threshold");
        check(StringAlgorithms.damerauLevenshtein("ca", "ac") == 1,
                "Damerau-Levenshtein");
        check("cde".equals(StringAlgorithms.longestCommonSubstring("abcde", "xcdef")),
                "suffix array/LCP");
        check("anana".equals(StringAlgorithms.longestCommonSubstring("banana", "ananas")),
                "suffix array repeated prefixes");
        check(DynamicProgramming.bestRestockValue(
                new int[] {2, 3, 4}, new int[] {3, 4, 5}, 5) == 7, "knapsack");
        check(DynamicProgramming.minimumAisleTour(new int[] {0, 2, 5}) == 10, "bitmask TSP");
        Dinic flow = new Dinic(4, 5);
        flow.addEdge(0, 1, 3);
        flow.addEdge(0, 2, 2);
        flow.addEdge(1, 2, 1);
        flow.addEdge(1, 3, 2);
        flow.addEdge(2, 3, 3);
        check(flow.maxFlow(0, 3) == 5, "Dinic max-flow");
        check(RandomizedAlgorithms.isProbablePrime(2_305_843_009_213_693_951L, 16),
                "Miller-Rabin large prime");
        check(!RandomizedAlgorithms.isProbablePrime(341_550_071_728_321L, 16),
                "Miller-Rabin composite");
        check(RandomizedAlgorithms.reservoirSample(new int[] {0, 1, 2, 3}, 2).length == 2,
                "reservoir sample");
        check(ParallelAlgorithms.parallelSum(new int[] {2, 3, 5}) == 10,
                "parallel reduction");
        long[] prefix = ParallelAlgorithms.parallelPrefixSum(new int[] {2, 3, 5});
        check(prefix[0] == 2 && prefix[1] == 5 && prefix[2] == 10, "parallel scan");
        Inventory sample = new Inventory();
        sample.loadSampleData();
        check(sample.size == 5 && sample.findBySku("SKU-1003") >= 0, "inventory");
        Corpus sampleCorpus = new Corpus();
        sampleCorpus.load(Paths.get("corpus"));
        check(sampleCorpus.size == 100, "100-document corpus");
        System.out.println("All 20 self-tests passed.");
    }

    private static String format(long[] values) {
        StringBuilder result = new StringBuilder("[");
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                result.append(", ");
            }
            result.append(values[i]);
        }
        return result.append(']').toString();
    }

    private static long sum(int[] values) {
        long total = 0;
        for (int value : values) {
            total += value;
        }
        return total;
    }

    private static int readNonNegativeInt(String label) throws IOException {
        while (true) {
            int value = readInt(label);
            if (value >= 0) {
                return value;
            }
            System.out.println("Enter a non-negative integer.");
        }
    }

    private static int readBoundedInt(String label, int minimum, int maximum) throws IOException {
        while (true) {
            String raw = prompt(label);
            if (raw == null) {
                return minimum;
            }
            int value;
            try {
                value = Integer.parseInt(raw.trim());
            } catch (NumberFormatException exception) {
                System.out.println("Enter a valid integer.");
                continue;
            }
            if (value >= minimum && value <= maximum) {
                return value;
            }
            System.out.println("Enter a value from " + minimum + " to " + maximum + ".");
        }
    }

    private static int readInt(String label) throws IOException {
        while (true) {
            String value = prompt(label);
            if (value == null) {
                return 0;
            }
            try {
                return Integer.parseInt(value.trim());
            } catch (NumberFormatException exception) {
                System.out.println("Enter a valid integer.");
            }
        }
    }

    private static long readLong(String label) throws IOException {
        while (true) {
            String value = prompt(label);
            if (value == null) {
                return 0;
            }
            try {
                return Long.parseLong(value.trim());
            } catch (NumberFormatException exception) {
                System.out.println("Enter a valid whole number.");
            }
        }
    }

    private static String prompt(String label) throws IOException {
        System.out.print(label);
        return INPUT.readLine();
    }

    private static void check(boolean passed, String name) {
        if (!passed) {
            throw new IllegalStateException("Self-test failed: " + name);
        }
    }

    private static final class Product {
        private final String sku;
        private final String name;
        private final String description;
        private int quantity;
        private final int reorderLevel;
        private final int aisle;

        private Product(String sku, String name, String description, int quantity,
                        int reorderLevel, int aisle) {
            this.sku = sku;
            this.name = name;
            this.description = description;
            this.quantity = quantity;
            this.reorderLevel = reorderLevel;
            this.aisle = aisle;
        }
    }

    private static final class Inventory {
        private Product[] products = new Product[8];
        private int size;

        private void loadSampleData() {
            add(new Product("SKU-1001", "Industrial Gloves",
                    "Cut resistant warehouse safety gloves", 45, 20, 1));
            add(new Product("SKU-1002", "Packing Tape",
                    "Heavy duty packing and sealing tape", 12, 25, 2));
            add(new Product("SKU-1003", "Shipping Box",
                    "Recyclable corrugated shipping box", 60, 30, 2));
            add(new Product("SKU-1004", "Barcode Labels",
                    "Thermal labels for inventory barcode scanners", 8, 20, 3));
            add(new Product("SKU-1005", "Safety Helmet",
                    "Protective helmet for warehouse staff", 18, 12, 1));
        }

        private void add(Product product) {
            if (size == products.length) {
                Product[] expanded = new Product[products.length * 2];
                System.arraycopy(products, 0, expanded, 0, size);
                products = expanded;
            }
            products[size++] = product;
        }

        private int findBySku(String sku) {
            for (int i = 0; i < size; i++) {
                if (products[i].sku.equalsIgnoreCase(sku)) {
                    return i;
                }
            }
            return -1;
        }

        private boolean removeBySku(String sku) {
            int index = findBySku(sku);
            if (index < 0) {
                return false;
            }
            for (int i = index; i < size - 1; i++) {
                products[i] = products[i + 1];
            }
            products[--size] = null;
            return true;
        }

        private void printAll() {
            if (size == 0) {
                System.out.println("Inventory is empty.");
                return;
            }
            System.out.printf("%-12s %-22s %8s %9s %7s%n",
                    "SKU", "Product", "Quantity", "Restock", "Aisle");
            for (int i = 0; i < size; i++) {
                printProduct(products[i]);
            }
        }

        private void printProduct(Product product) {
            System.out.printf("%-12s %-22s %8d %9d %7d%n",
                    product.sku, product.name, product.quantity,
                    product.reorderLevel, product.aisle);
        }
    }

    private static final class Corpus {
        private String[] names = new String[16];
        private String[] contents = new String[16];
        private int size;

        private void load(Path directory) throws IOException {
            if (!Files.isDirectory(directory)) {
                throw new IOException("Corpus directory not found: " + directory.toAbsolutePath());
            }
            try (DirectoryStream<Path> files = Files.newDirectoryStream(directory, "*.txt")) {
                for (Path file : files) {
                    if (size == names.length) {
                        String[] expandedNames = new String[names.length * 2];
                        String[] expandedContents = new String[contents.length * 2];
                        System.arraycopy(names, 0, expandedNames, 0, size);
                        System.arraycopy(contents, 0, expandedContents, 0, size);
                        names = expandedNames;
                        contents = expandedContents;
                    }
                    names[size] = file.getFileName().toString();
                    contents[size] = Files.readString(file);
                    if (contents[size].startsWith("\uFEFF")) {
                        contents[size] = contents[size].substring(1);
                    }
                    size++;
                }
            }
            if (size == 0) {
                throw new IOException("No .txt corpus documents found in "
                        + directory.toAbsolutePath() + ".");
            }
        }

        private String preview(int index) {
            String compact = contents[index].replace('\r', ' ').replace('\n', ' ').trim();
            return compact.length() <= 180 ? compact : compact.substring(0, 177) + "...";
        }
    }

    private static final class StringAlgorithms {
        private static int kmpIndexOf(String text, String pattern) {
            if (pattern.isEmpty()) {
                return 0;
            }
            int[] failure = new int[pattern.length()];
            for (int i = 1, matched = 0; i < pattern.length();) {
                if (pattern.charAt(i) == pattern.charAt(matched)) {
                    failure[i++] = ++matched;
                } else if (matched > 0) {
                    matched = failure[matched - 1];
                } else {
                    failure[i++] = 0;
                }
            }
            for (int i = 0, matched = 0; i < text.length();) {
                if (text.charAt(i) == pattern.charAt(matched)) {
                    i++;
                    if (++matched == pattern.length()) {
                        return i - matched;
                    }
                } else if (matched > 0) {
                    matched = failure[matched - 1];
                } else {
                    i++;
                }
            }
            return -1;
        }

        private static int zIndexOf(String text, String pattern) {
            if (pattern.isEmpty()) {
                return 0;
            }
            String combined = pattern + '\u0000' + text;
            int[] z = new int[combined.length()];
            for (int i = 1, left = 0, right = 0; i < combined.length(); i++) {
                if (i <= right) {
                    z[i] = Math.min(right - i + 1, z[i - left]);
                }
                while (i + z[i] < combined.length()
                        && combined.charAt(z[i]) == combined.charAt(i + z[i])) {
                    z[i]++;
                }
                if (i + z[i] - 1 > right) {
                    left = i;
                    right = i + z[i] - 1;
                }
                if (z[i] >= pattern.length()) {
                    return i - pattern.length() - 1;
                }
            }
            return -1;
        }

        private static int rabinKarpIndexOf(String text, String pattern) {
            if (pattern.isEmpty()) {
                return 0;
            }
            if (pattern.length() > text.length()) {
                return -1;
            }
            final long mod1 = 1_000_000_007L;
            final long mod2 = 1_000_000_009L;
            final long base = 257L;
            long pattern1 = 0;
            long pattern2 = 0;
            long window1 = 0;
            long window2 = 0;
            long power1 = 1;
            long power2 = 1;
            int width = pattern.length();
            for (int i = 0; i < width; i++) {
                pattern1 = (pattern1 * base + pattern.charAt(i)) % mod1;
                pattern2 = (pattern2 * base + pattern.charAt(i)) % mod2;
                window1 = (window1 * base + text.charAt(i)) % mod1;
                window2 = (window2 * base + text.charAt(i)) % mod2;
                if (i < width - 1) {
                    power1 = power1 * base % mod1;
                    power2 = power2 * base % mod2;
                }
            }
            for (int start = 0; ; start++) {
                if (pattern1 == window1 && pattern2 == window2
                        && text.regionMatches(start, pattern, 0, width)) {
                    return start;
                }
                int next = start + width;
                if (next >= text.length()) {
                    break;
                }
                window1 = ((window1 - text.charAt(start) * power1 % mod1 + mod1)
                        * base + text.charAt(next)) % mod1;
                window2 = ((window2 - text.charAt(start) * power2 % mod2 + mod2)
                        * base + text.charAt(next)) % mod2;
            }
            return -1;
        }

        private static boolean ahoCorasickContainsAny(String text, String[] patterns) {
            int capacity = 1;
            for (String pattern : patterns) {
                if (pattern != null) {
                    capacity += pattern.length();
                }
            }
            int[] head = new int[capacity];
            int[] fail = new int[capacity];
            boolean[] output = new boolean[capacity];
            int[] edgeTo = new int[Math.max(1, capacity - 1)];
            int[] edgeNext = new int[edgeTo.length];
            char[] edgeChar = new char[edgeTo.length];
            for (int i = 0; i < head.length; i++) {
                head[i] = -1;
            }
            int nodes = 1;
            int edges = 0;
            for (String raw : patterns) {
                if (raw == null || raw.isEmpty()) {
                    continue;
                }
                String pattern = raw.toLowerCase();
                int state = 0;
                for (int i = 0; i < pattern.length(); i++) {
                    char c = pattern.charAt(i);
                    int edge = findEdge(state, c, head, edgeTo, edgeNext, edgeChar);
                    if (edge < 0) {
                        int child = nodes++;
                        edgeTo[edges] = child;
                        edgeChar[edges] = c;
                        edgeNext[edges] = head[state];
                        head[state] = edges++;
                        state = child;
                    } else {
                        state = edgeTo[edge];
                    }
                }
                output[state] = true;
            }
            int[] queue = new int[nodes];
            int first = 0;
            int last = 0;
            for (int edge = head[0]; edge >= 0; edge = edgeNext[edge]) {
                queue[last++] = edgeTo[edge];
            }
            while (first < last) {
                int state = queue[first++];
                for (int edge = head[state]; edge >= 0; edge = edgeNext[edge]) {
                    int child = edgeTo[edge];
                    char c = edgeChar[edge];
                    int fallback = fail[state];
                    int transition = findEdge(fallback, c, head, edgeTo, edgeNext, edgeChar);
                    while (fallback != 0 && transition < 0) {
                        fallback = fail[fallback];
                        transition = findEdge(fallback, c, head, edgeTo, edgeNext, edgeChar);
                    }
                    fail[child] = transition < 0 ? 0 : edgeTo[transition];
                    output[child] |= output[fail[child]];
                    queue[last++] = child;
                }
            }
            int state = 0;
            String normalized = text.toLowerCase();
            for (int i = 0; i < normalized.length(); i++) {
                char c = normalized.charAt(i);
                int transition = findEdge(state, c, head, edgeTo, edgeNext, edgeChar);
                while (state != 0 && transition < 0) {
                    state = fail[state];
                    transition = findEdge(state, c, head, edgeTo, edgeNext, edgeChar);
                }
                state = transition < 0 ? 0 : edgeTo[transition];
                if (output[state]) {
                    return true;
                }
            }
            return false;
        }

        private static int findEdge(int state, char c, int[] head, int[] edgeTo,
                                    int[] edgeNext, char[] edgeChar) {
            for (int edge = head[state]; edge >= 0; edge = edgeNext[edge]) {
                if (edgeChar[edge] == c) {
                    return edge;
                }
            }
            return -1;
        }

        private static int editDistance(String first, String second) {
            int[] previous = new int[second.length() + 1];
            int[] current = new int[second.length() + 1];
            for (int j = 0; j <= second.length(); j++) {
                previous[j] = j;
            }
            for (int i = 1; i <= first.length(); i++) {
                current[0] = i;
                for (int j = 1; j <= second.length(); j++) {
                    int substitution = previous[j - 1]
                            + (first.charAt(i - 1) == second.charAt(j - 1) ? 0 : 1);
                    current[j] = Math.min(substitution,
                            Math.min(previous[j] + 1, current[j - 1] + 1));
                }
                int[] swap = previous;
                previous = current;
                current = swap;
            }
            return previous[second.length()];
        }

        private static boolean fuzzyContains(String text, String pattern, int maxDistance) {
            if (pattern.isEmpty()) {
                return true;
            }
            int[] previous = new int[text.length() + 1];
            int[] current = new int[text.length() + 1];
            for (int row = 1; row <= pattern.length(); row++) {
                current[0] = row;
                for (int column = 1; column <= text.length(); column++) {
                    int substitution = previous[column - 1]
                            + (pattern.charAt(row - 1) == text.charAt(column - 1) ? 0 : 1);
                    current[column] = Math.min(substitution,
                            Math.min(previous[column] + 1, current[column - 1] + 1));
                }
                int[] swap = previous;
                previous = current;
                current = swap;
            }
            for (int column = 0; column <= text.length(); column++) {
                if (previous[column] <= maxDistance) {
                    return true;
                }
            }
            return false;
        }

        private static int damerauLevenshtein(String first, String second) {
            int[][] distance = new int[first.length() + 1][second.length() + 1];
            for (int i = 0; i <= first.length(); i++) {
                distance[i][0] = i;
            }
            for (int j = 0; j <= second.length(); j++) {
                distance[0][j] = j;
            }
            for (int i = 1; i <= first.length(); i++) {
                for (int j = 1; j <= second.length(); j++) {
                    int cost = first.charAt(i - 1) == second.charAt(j - 1) ? 0 : 1;
                    distance[i][j] = Math.min(
                            Math.min(distance[i - 1][j] + 1, distance[i][j - 1] + 1),
                            distance[i - 1][j - 1] + cost);
                    if (i > 1 && j > 1
                            && first.charAt(i - 1) == second.charAt(j - 2)
                            && first.charAt(i - 2) == second.charAt(j - 1)) {
                        distance[i][j] = Math.min(distance[i][j],
                                distance[i - 2][j - 2] + 1);
                    }
                }
            }
            return distance[first.length()][second.length()];
        }

        private static String longestCommonSubstring(String first, String second) {
            String joined = first + '\u0000' + second;
            int[] suffixArray = suffixArray(joined);
            int[] lcp = kasai(joined, suffixArray);
            int boundary = first.length();
            int bestLength = 0;
            int bestStart = 0;
            for (int i = 1; i < suffixArray.length; i++) {
                int left = suffixArray[i - 1];
                int right = suffixArray[i];
                boolean leftInFirst = left < boundary;
                boolean rightInFirst = right < boundary;
                if (leftInFirst == rightInFirst || left == boundary || right == boundary) {
                    continue;
                }
                int leftLimit = leftInFirst ? boundary - left : joined.length() - left;
                int rightLimit = rightInFirst ? boundary - right : joined.length() - right;
                int length = Math.min(lcp[i], Math.min(leftLimit, rightLimit));
                if (length > bestLength) {
                    bestLength = length;
                    bestStart = leftInFirst ? left : right;
                }
            }
            return joined.substring(bestStart, bestStart + bestLength);
        }

        private static int[] suffixArray(String text) {
            int n = text.length();
            int[] suffixes = new int[n];
            int[] ranks = new int[n];
            int[] nextRanks = new int[n];
            int[] temporary = new int[n];
            for (int i = 0; i < n; i++) {
                suffixes[i] = i;
                ranks[i] = text.charAt(i);
            }
            for (int width = 1; width < n; width = width > n / 2 ? n : width * 2) {
                mergeSortSuffixes(suffixes, temporary, 0, n, ranks, width, n);
                int classes = 0;
                nextRanks[suffixes[0]] = 0;
                for (int i = 1; i < n; i++) {
                    if (compareSuffix(suffixes[i - 1], suffixes[i], ranks, width, n) != 0) {
                        classes++;
                    }
                    nextRanks[suffixes[i]] = classes;
                }
                int[] swap = ranks;
                ranks = nextRanks;
                nextRanks = swap;
                if (classes == n - 1) {
                    break;
                }
            }
            return suffixes;
        }

        private static void mergeSortSuffixes(int[] values, int[] temporary, int start,
                                              int end, int[] ranks, int width, int n) {
            if (end - start <= 1) {
                return;
            }
            int middle = start + (end - start) / 2;
            mergeSortSuffixes(values, temporary, start, middle, ranks, width, n);
            mergeSortSuffixes(values, temporary, middle, end, ranks, width, n);
            int left = start;
            int right = middle;
            int out = start;
            while (left < middle && right < end) {
                if (compareSuffix(values[left], values[right], ranks, width, n) <= 0) {
                    temporary[out++] = values[left++];
                } else {
                    temporary[out++] = values[right++];
                }
            }
            while (left < middle) {
                temporary[out++] = values[left++];
            }
            while (right < end) {
                temporary[out++] = values[right++];
            }
            System.arraycopy(temporary, start, values, start, end - start);
        }

        private static int compareSuffix(int first, int second, int[] ranks, int width, int n) {
            if (ranks[first] != ranks[second]) {
                return Integer.compare(ranks[first], ranks[second]);
            }
            int firstRank = first + width < n ? ranks[first + width] : -1;
            int secondRank = second + width < n ? ranks[second + width] : -1;
            return Integer.compare(firstRank, secondRank);
        }

        private static int[] kasai(String text, int[] suffixArray) {
            int n = text.length();
            int[] rank = new int[n];
            int[] lcp = new int[n];
            for (int i = 0; i < n; i++) {
                rank[suffixArray[i]] = i;
            }
            int common = 0;
            for (int start = 0; start < n; start++) {
                int position = rank[start];
                if (position == 0) {
                    common = 0;
                    continue;
                }
                int previous = suffixArray[position - 1];
                while (start + common < n && previous + common < n
                        && text.charAt(start + common) == text.charAt(previous + common)) {
                    common++;
                }
                lcp[position] = common;
                if (common > 0) {
                    common--;
                }
            }
            return lcp;
        }
    }

    private static final class DynamicProgramming {
        private static int bestRestockValue(int[] weights, int[] values, int capacity) {
            int[] best = new int[capacity + 1];
            for (int i = 0; i < weights.length; i++) {
                for (int budget = capacity; budget >= weights[i]; budget--) {
                    best[budget] = Math.max(best[budget],
                            best[budget - weights[i]] + values[i]);
                }
            }
            return best[capacity];
        }

        private static int minimumAisleTour(int[] aisles) {
            int n = aisles.length;
            if (n <= 1) {
                return 0;
            }
            int states = 1 << n;
            int infinity = Integer.MAX_VALUE / 4;
            int[][] dp = new int[states][n];
            for (int mask = 0; mask < states; mask++) {
                for (int end = 0; end < n; end++) {
                    dp[mask][end] = infinity;
                }
            }
            dp[1][0] = 0;
            for (int mask = 1; mask < states; mask++) {
                if ((mask & 1) == 0) {
                    continue;
                }
                for (int end = 0; end < n; end++) {
                    if ((mask & (1 << end)) == 0 || dp[mask][end] == infinity) {
                        continue;
                    }
                    for (int next = 1; next < n; next++) {
                        if ((mask & (1 << next)) == 0) {
                            int nextMask = mask | (1 << next);
                            int distance = Math.abs(aisles[end] - aisles[next]);
                            dp[nextMask][next] = Math.min(dp[nextMask][next],
                                    dp[mask][end] + distance);
                        }
                    }
                }
            }
            int complete = states - 1;
            int best = infinity;
            for (int end = 1; end < n; end++) {
                best = Math.min(best, dp[complete][end]
                        + Math.abs(aisles[end] - aisles[0]));
            }
            return best;
        }
    }

    private static final class Dinic {
        private final int[] head;
        private final int[] to;
        private final int[] next;
        private final int[] capacity;
        private final int[] level;
        private final int[] current;
        private int edgeCount;

        private Dinic(int vertices, int directedEdges) {
            head = new int[vertices];
            to = new int[Math.max(2, directedEdges * 2)];
            next = new int[to.length];
            capacity = new int[to.length];
            level = new int[vertices];
            current = new int[vertices];
            for (int i = 0; i < vertices; i++) {
                head[i] = -1;
            }
        }

        private void addEdge(int from, int destination, int edgeCapacity) {
            to[edgeCount] = destination;
            capacity[edgeCount] = edgeCapacity;
            next[edgeCount] = head[from];
            head[from] = edgeCount++;
            to[edgeCount] = from;
            capacity[edgeCount] = 0;
            next[edgeCount] = head[destination];
            head[destination] = edgeCount++;
        }

        private int maxFlow(int source, int sink) {
            int total = 0;
            while (buildLevels(source, sink)) {
                System.arraycopy(head, 0, current, 0, head.length);
                int pushed;
                while ((pushed = send(source, sink, Integer.MAX_VALUE)) > 0) {
                    total += pushed;
                }
            }
            return total;
        }

        private boolean buildLevels(int source, int sink) {
            for (int i = 0; i < level.length; i++) {
                level[i] = -1;
            }
            int[] queue = new int[level.length];
            int first = 0;
            int last = 0;
            queue[last++] = source;
            level[source] = 0;
            while (first < last) {
                int vertex = queue[first++];
                for (int edge = head[vertex]; edge >= 0; edge = next[edge]) {
                    if (capacity[edge] > 0 && level[to[edge]] < 0) {
                        level[to[edge]] = level[vertex] + 1;
                        queue[last++] = to[edge];
                    }
                }
            }
            return level[sink] >= 0;
        }

        private int send(int vertex, int sink, int available) {
            if (vertex == sink) {
                return available;
            }
            for (int edge = current[vertex]; edge >= 0; edge = next[edge]) {
                current[vertex] = edge;
                if (capacity[edge] > 0 && level[to[edge]] == level[vertex] + 1) {
                    int pushed = send(to[edge], sink, Math.min(available, capacity[edge]));
                    if (pushed > 0) {
                        capacity[edge] -= pushed;
                        capacity[edge ^ 1] += pushed;
                        return pushed;
                    }
                }
                current[vertex] = next[edge];
            }
            return 0;
        }

        private int flowOnEdge(int from, int destination) {
            for (int edge = head[from]; edge >= 0; edge = next[edge]) {
                if (to[edge] == destination && (edge & 1) == 0) {
                    return capacity[edge ^ 1];
                }
            }
            return 0;
        }
    }

    private static final class RandomizedAlgorithms {
        private static long randomState = System.nanoTime() ^ 0x9E3779B97F4A7C15L;

        private static boolean isProbablePrime(long number, int rounds) {
            if (number < 2) {
                return false;
            }
            int[] smallPrimes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37};
            for (int prime : smallPrimes) {
                if (number == prime) {
                    return true;
                }
                if (number % prime == 0) {
                    return false;
                }
            }
            if ((number & 1L) == 0) {
                return false;
            }
            long d = number - 1;
            int powersOfTwo = 0;
            while ((d & 1L) == 0) {
                d >>>= 1;
                powersOfTwo++;
            }
            for (int round = 0; round < rounds; round++) {
                long witness = 2 + nextRandomLong(number - 3);
                long value = modularPower(witness, d, number);
                if (value == 1 || value == number - 1) {
                    continue;
                }
                boolean passes = false;
                for (int r = 1; r < powersOfTwo; r++) {
                    value = modularMultiply(value, value, number);
                    if (value == number - 1) {
                        passes = true;
                        break;
                    }
                }
                if (!passes) {
                    return false;
                }
            }
            return true;
        }

        private static long modularPower(long base, long exponent, long modulus) {
            long result = 1;
            long value = base % modulus;
            while (exponent > 0) {
                if ((exponent & 1L) != 0) {
                    result = modularMultiply(result, value, modulus);
                }
                value = modularMultiply(value, value, modulus);
                exponent >>>= 1;
            }
            return result;
        }

        private static long modularMultiply(long first, long second, long modulus) {
            long result = 0;
            long value = first;
            long multiplier = second;
            while (multiplier > 0) {
                if ((multiplier & 1L) != 0) {
                    result = addModulo(result, value, modulus);
                }
                value = addModulo(value, value, modulus);
                multiplier >>>= 1;
            }
            return result;
        }

        private static long addModulo(long first, long second, long modulus) {
            return first >= modulus - second
                    ? first - (modulus - second)
                    : first + second;
        }

        private static long nextRandomLong(long bound) {
            randomState ^= randomState << 13;
            randomState ^= randomState >>> 7;
            randomState ^= randomState << 17;
            return Long.remainderUnsigned(randomState, bound);
        }

        private static int[] reservoirSample(int[] input, int sampleSize) {
            if (sampleSize < 0 || sampleSize > input.length) {
                throw new IllegalArgumentException("Sample size must be within input bounds.");
            }
            int[] sample = new int[sampleSize];
            for (int i = 0; i < sampleSize; i++) {
                sample[i] = input[i];
            }
            for (int i = sampleSize; i < input.length; i++) {
                long slot = nextRandomLong(i + 1L);
                if (slot < sampleSize) {
                    sample[(int) slot] = input[i];
                }
            }
            return sample;
        }
    }

    private static final class ParallelAlgorithms {
        private static long parallelSum(int[] values) {
            int workers = workerCount(values.length);
            long[] partial = new long[workers];
            Thread[] threads = new Thread[workers];
            for (int worker = 0; worker < workers; worker++) {
                final int index = worker;
                final int start = values.length * worker / workers;
                final int end = values.length * (worker + 1) / workers;
                threads[worker] = new Thread(() -> {
                    long subtotal = 0;
                    for (int i = start; i < end; i++) {
                        subtotal += values[i];
                    }
                    partial[index] = subtotal;
                });
                threads[worker].start();
            }
            joinAll(threads);
            long total = 0;
            for (long subtotal : partial) {
                total += subtotal;
            }
            return total;
        }

        private static long[] parallelPrefixSum(int[] values) {
            int workers = workerCount(values.length);
            long[] prefix = new long[values.length];
            long[] totals = new long[workers];
            Thread[] threads = new Thread[workers];
            for (int worker = 0; worker < workers; worker++) {
                final int index = worker;
                final int start = values.length * worker / workers;
                final int end = values.length * (worker + 1) / workers;
                threads[worker] = new Thread(() -> {
                    long subtotal = 0;
                    for (int i = start; i < end; i++) {
                        subtotal += values[i];
                        prefix[i] = subtotal;
                    }
                    totals[index] = subtotal;
                });
                threads[worker].start();
            }
            joinAll(threads);
            long offset = 0;
            for (int worker = 0; worker < workers; worker++) {
                int start = values.length * worker / workers;
                int end = values.length * (worker + 1) / workers;
                for (int i = start; i < end; i++) {
                    prefix[i] += offset;
                }
                offset += totals[worker];
            }
            return prefix;
        }

        private static int workerCount(int size) {
            if (size == 0) {
                return 1;
            }
            return Math.max(1, Math.min(size, Runtime.getRuntime().availableProcessors()));
        }

        private static void joinAll(Thread[] threads) {
            for (Thread thread : threads) {
                try {
                    thread.join();
                } catch (InterruptedException exception) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException("Parallel computation was interrupted.", exception);
                }
            }
        }
    }
}
